package com.cg.insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.insurance.bean.CreateAccount;
import com.cg.insurance.bean.DetailedReportBean;
import com.cg.insurance.bean.InsuranceFormBean;
import com.cg.insurance.bean.NewPolicySchemeBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.Question;
import com.cg.insurance.bean.ReportGeneration;
import com.cg.insurance.exception.InsuranceException;
import com.cg.insurance.util.DBConnection;

public class InsuredDaoImpl implements IInsuredDao {
	Logger logger=Logger.getRootLogger();
	public InsuredDaoImpl()
	{
	PropertyConfigurator.configure("Resources//log4j.properties");
	
	}


	@Override
	public String login(String userName, String password) throws SQLException, IOException, InsuranceException {
		Connection con = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			logger.info("user is logging in ");
			preparedStatement = con.prepareStatement("select rolecode from userrole where username = ? and password = ?");
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			String roleC = null;
			while(resultSet.next()) {
				roleC = resultSet.getString(1);
				//System.out.println(" "+roleC);
				logger.info("login successful");
			}
			if( roleC != null)
			{
				logger.info("Roll code Found Successfully");
				return roleC;
				
			}
			else
			{
				logger.error("Roll code Not Found Successfully");
				return null;
			}	
			
		}catch(Exception e) {
			
			logger.error(e.getMessage());
			throw new InsuranceException(e.getMessage());
			
		}		
		//return null;
	}
	
	@Override
	public List<PolicyBean> viewAllPolicies() throws Exception {
		
		Connection con = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = con.prepareStatement("select * from policy");
			resultSet = preparedStatement.executeQuery();
			List<PolicyBean> list = new ArrayList<>();
			PolicyBean policyBean = new PolicyBean();
			while(resultSet.next()) {
				
				policyBean.setPolicyNumber(resultSet.getLong(1));
				policyBean.setPolicyPremium(resultSet.getInt(2));
				policyBean.setAccountNumber(resultSet.getDouble(3));
				list.add(policyBean);
			}
			if( policyBean != null)
			{
				logger.info("Record Found Successfully");
				return list;
			}
			else
			{
				logger.error("Record Not Found Successfully");
				return null;
			}	
		}catch(Exception e) {

			logger.error(e.getMessage());
			throw new InsuranceException(e.getMessage());
			
		}
		
		//return null;
	}


	@Override
	public List<PolicyBean> viewMyPolicies(String userName) throws Exception {
		
		Connection con1=DBConnection.getConnection();
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet1=null;
		try {
			preparedStatement1=con1.prepareStatement("select policynumber,policypremimum,b.accountnumber from account a,policy b where a.username=? and a.accountnumber=b.accountnumber");
			preparedStatement1.setString(1, userName);
			resultSet1=preparedStatement1.executeQuery();
			List<PolicyBean> list1 = new ArrayList<>();
			PolicyBean policyBean=new PolicyBean();

			while(resultSet1.next()) {
			    policyBean.setPolicyNumber(resultSet1.getLong(1));
				policyBean.setPolicyPremium(resultSet1.getInt(2));
				policyBean.setAccountNumber(resultSet1.getDouble(3));
				list1.add(policyBean);
			}
			
			if( policyBean != null)
			{
				logger.info("policy Found Successfully");
				return list1;
			}
			else
			{
				logger.error("policy Not Found Successfully");
				return null;
			}
			
		}catch(Exception ex) {

			logger.error(ex.getMessage());
			throw new InsuranceException(ex.getMessage());
			
		}
		
		//return null;
	}

	
	@Override
	public String newPolicy(InsuranceFormBean insuranceFormBean) throws Exception {
		Connection con=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		{
			int query=0;
			try {
		
			preparedStatement = con.prepareStatement("insert into account values(account_number_seq1.nextval,?,?,?,?,?,?,?,0)");
			preparedStatement.setString(1, insuranceFormBean.getInsuredName());
			preparedStatement.setString(2, insuranceFormBean.getInsuredStreet());
			preparedStatement.setString(3, insuranceFormBean.getInsuredCity());
			preparedStatement.setString(4, insuranceFormBean.getInsuredState());
			preparedStatement.setInt(5, insuranceFormBean.getInsuredZip());
			preparedStatement.setString(6, insuranceFormBean.getBusinessSegment());
			preparedStatement.setString(7, insuranceFormBean.getUserName());
			query=preparedStatement.executeUpdate();
			
			if(query==0)
			{
				logger.error("account details insertion failed ");
				throw new InsuranceException("Inserting  details failed ");

			}
			else
			{
				logger.info("account details added successfully:");
				return "inserted";
			}
			

			}catch(Exception e) {

				logger.error(e.getMessage());
				throw new InsuranceException(e.getMessage());
			}
		}
		//return null;
	}


	@Override
	public List<Question> getQuestions(String businessSegment) throws SQLException, IOException, InsuranceException {
		Connection con=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		try {
			System.out.println("in");
			preparedStatement = con.prepareStatement("select pol_ques_id,a.bus_seg_id,pol_ques_desc,pol_ques_ans1,pol_ques_ans1_weightage,pol_ques_ans2,pol_ques_ans2_weightage,pol_ques_ans3,pol_ques_ans3_weightage from policyquestion a,businesssegment b where bus_seg_name=? and a.bus_seg_id=b.bus_seg_id");
			preparedStatement.setString(1, businessSegment);
			resultSet = preparedStatement.executeQuery();
			List<Question> list = new ArrayList<>();
			Iterator<Question> itr = list.iterator();
			System.out.println("in1");
			Question question = new Question();
			while(resultSet.next()) {
			
				question.setPolicyQuestionId(resultSet.getInt(1));
				question.setBusinessSegmentId(resultSet.getInt(2));
				question.setQuestion(resultSet.getString(3));
				question.setAnswer1(resultSet.getString(4));
				question.setWeightage1(resultSet.getInt(5));
				question.setAnswer2(resultSet.getString(6));
				question.setWeightage2(resultSet.getInt(7));
				question.setAnswer3(resultSet.getString(8));
				question.setWeightage3(resultSet.getInt(9));
				list.add(question);
			}
			//System.out.println("in2");
			
			if( question != null)
			{
				logger.info("question details Found Successfully");
				return list;
			}
			else
			{
				logger.error("question details Not Found Successfully");
				return null;
			}
			
		}catch(Exception e) {

			logger.error(e.getMessage());
			throw new InsuranceException(e.getMessage());
		}
		
		//return null;
	}


	@Override
	public boolean setPremium(int premium) throws SQLException, IOException {
		Connection con=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		try {
		
		}catch(Exception e) {
			logger.error(e.getMessage());
			System.err.println(e.getMessage());
		}
		return false;
	}


	@Override
	public void createAccount(CreateAccount createBean) throws SQLException, IOException, InsuranceException {
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{ int query=0;
				ps=connection.prepareStatement("insert into userrole values(?,?,?)");
				CreateAccount.role roleCode = createBean.getRole_code();
				ps.setString(1,createBean.getUsername());
				ps.setString(2,createBean.getPassword());
				ps.setString(3,roleCode.name());
				query=ps.executeUpdate();
				System.out.println("Inserted");
				if(query==0)
				{
					logger.error("login details insertion failed ");
					throw new InsuranceException("Inserting login details failed ");

				}
				else
				{
					logger.info("login details added successfully:");
					
				}
				
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new InsuranceException(e.getMessage());
		}

		
	}


	@Override
	public List<ReportGeneration> generateReport(String userName) throws SQLException, IOException {
		
		Connection connection= DBConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps = connection.prepareStatement("select policy_id_seq.nextval,a.accountNumber,b.policynumber,b.policypremium from accounts a,policy b where a.username=?");
			ps.setString(1, userName);
			rs = ps.executeQuery();
			List<ReportGeneration> li = new ArrayList<>();
			ReportGeneration reportGeneration = new ReportGeneration();
			while(rs.next()) {
				
				reportGeneration.setSerialNo(rs.getInt(1));
				reportGeneration.setAccountNumber(rs.getLong(2));
				reportGeneration.setPolicyNumber(rs.getLong(3));
				reportGeneration.setPolicyPremium(rs.getDouble(4));
				li.add(reportGeneration);
			}
			if( reportGeneration != null)
			{
				logger.info("Details Found Successfully");
				return li;
			}
			else
			{
				logger.error(" Details Not Found Successfully");
				return null;
			}
			
			
		}catch(Exception e) {
			logger.error(e.getMessage());
			e.getMessage();
		}
		return null;
	}


	@Override
	public DetailedReportBean getDetailedReport(long policyNumber) throws SQLException, IOException {
		Connection connection= DBConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			
			ps = connection.prepareStatement("select a.insuredName,a.insuredStreet,a.insuredCity,a.insuredState,a.insuredZip,a.businessSegment,a.quesDesc1,a.quesDesc2,a.quesDesc3,a.quesDesc4,a.quesDesc5,a.coverage1,a.coverage2,a.coverage3,b.policypremium from userRequest a,policy b where b.policyNumber=? AND a.accountnumber=b.accountnumber");
			ps.setLong(1, policyNumber);
			rs = ps.executeQuery();
			DetailedReportBean detailedReportBean = new DetailedReportBean();
			while(rs.next()) {
				detailedReportBean.setInsuredName(rs.getString(1));
				detailedReportBean.setInsuredStreet(rs.getString(2));
				detailedReportBean.setInsuredCity(rs.getString(3));
				detailedReportBean.setInsuredState(rs.getString(4));
				detailedReportBean.setInsuredZip(rs.getInt(5));
				detailedReportBean.setBusinessSegment(rs.getString(6));
				detailedReportBean.setQuesDesc1(rs.getString(7));
				detailedReportBean.setQuesDesc2(rs.getString(8));
				detailedReportBean.setQuesDesc3(rs.getString(9));
				detailedReportBean.setQuesDesc4(rs.getString(10));
				detailedReportBean.setQuesDesc5(rs.getString(11));
				detailedReportBean.setCoverage1(rs.getString(12));
				detailedReportBean.setCoverage2(rs.getString(13));
				detailedReportBean.setCoverage3(rs.getString(14));
				detailedReportBean.setPremiumAmount(rs.getDouble(15));
			}
			if( detailedReportBean != null)
			{
				logger.info("Detailed reports Found Successfully");
				return detailedReportBean;
			}
			else
			{
				logger.error(" Detailed reports Not Found Successfully");
				return null;
			}

			
			
		}catch(Exception e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public void createNewScheme(NewPolicySchemeBean newPolicySchemeBean) throws SQLException, IOException, InsuranceException {
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			int query=0;
				ps=connection.prepareStatement("insert into business_segment values(?,?)");
				ps.setInt(1,newPolicySchemeBean.getBus_seg_id());
				ps.setString(2,newPolicySchemeBean.getBus_seg_name());
				ps.executeUpdate();
				System.out.println("Inserted into Business_Segement Table");
				PreparedStatement ps_pol_stat=connection.prepareStatement("insert into policy_questions values(?,?,?,?,?,?,?,?,?)");
				ps_pol_stat.setInt(1,newPolicySchemeBean.getPol_ques_id());
				ps_pol_stat.setInt(2,newPolicySchemeBean.getBus_seg_id());
				ps_pol_stat.setString(3,newPolicySchemeBean.getPol_ques_desc());
				ps_pol_stat.setString(4,newPolicySchemeBean.getPol_ques_ans1());
				ps_pol_stat.setInt(5,newPolicySchemeBean.getPol_ques_ans1_weightage());
				ps_pol_stat.setString(6,newPolicySchemeBean.getPol_ques_ans2());
				ps_pol_stat.setInt(7,newPolicySchemeBean.getPol_ques_ans2_weightage());
				ps_pol_stat.setString(8,newPolicySchemeBean.getPol_ques_ans3());
				ps_pol_stat.setInt(9,newPolicySchemeBean.getPol_ques_ans3_weightage());
				query=ps_pol_stat.executeUpdate();
				System.out.println("Inserted into Policy_Ques Table");
				if(query==0)
				{
					logger.error("questions insertion failed ");
					throw new InsuranceException("Inserting questions failed ");

				}
				else
				{
					logger.info("questions details added successfully:");
					
				}

				
		
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new InsuranceException(e.getMessage());
		}
		
	}

}
