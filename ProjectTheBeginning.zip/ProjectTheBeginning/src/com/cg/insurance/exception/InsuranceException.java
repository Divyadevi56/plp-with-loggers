package com.cg.insurance.exception;

public class InsuranceException extends Exception{
	public InsuranceException(String message) 
	{
		
		super(message);
	}

}
