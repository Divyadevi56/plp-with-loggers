package com.cg.insurance.bean;

public class NewPolicySchemeBean {
	
	private int bus_seg_id;
	private String bus_seg_name;
	private int pol_ques_id;
	private String pol_ques_desc;
	private String pol_ques_ans1;
	private int pol_ques_ans1_weightage;
	private String pol_ques_ans2;
	private int pol_ques_ans2_weightage;
	private String pol_ques_ans3;
	private int pol_ques_ans3_weightage;
	
	
	
	public int getBus_seg_id() {
		return bus_seg_id;
	}
	public void setBus_seg_id(int bus_seg_id) {
		this.bus_seg_id = bus_seg_id;
	}
	public String getBus_seg_name() {
		return bus_seg_name;
	}
	public void setBus_seg_name(String bus_seg_name) {
		this.bus_seg_name = bus_seg_name;
	}
	public int getPol_ques_id() {
		return pol_ques_id;
	}
	public void setPol_ques_id(int pol_ques_id) {
		this.pol_ques_id = pol_ques_id;
	}
	public String getPol_ques_desc() {
		return pol_ques_desc;
	}
	public void setPol_ques_desc(String pol_ques_desc) {
		this.pol_ques_desc = pol_ques_desc;
	}
	public String getPol_ques_ans1() {
		return pol_ques_ans1;
	}
	public void setPol_ques_ans1(String pol_ques_ans1) {
		this.pol_ques_ans1 = pol_ques_ans1;
	}
	public int getPol_ques_ans1_weightage() {
		return pol_ques_ans1_weightage;
	}
	public void setPol_ques_ans1_weightage(int pol_ques_ans1_weightage) {
		this.pol_ques_ans1_weightage = pol_ques_ans1_weightage;
	}
	public String getPol_ques_ans2() {
		return pol_ques_ans2;
	}
	public void setPol_ques_ans2(String pol_ques_ans2) {
		this.pol_ques_ans2 = pol_ques_ans2;
	}
	public int getPol_ques_ans2_weightage() {
		return pol_ques_ans2_weightage;
	}
	public void setPol_ques_ans2_weightage(int pol_ques_ans2_weightage) {
		this.pol_ques_ans2_weightage = pol_ques_ans2_weightage;
	}
	public String getPol_ques_ans3() {
		return pol_ques_ans3;
	}
	public void setPol_ques_ans3(String pol_ques_ans3) {
		this.pol_ques_ans3 = pol_ques_ans3;
	}
	public int getPol_ques_ans3_weightage() {
		return pol_ques_ans3_weightage;
	}
	public void setPol_ques_ans3_weightage(int pol_ques_ans3_weightage) {
		this.pol_ques_ans3_weightage = pol_ques_ans3_weightage;
	}
	
	
	
}
